// ==========================================
// HORIZON HOUSE PBX SERVER - CLOUD DEPLOYMENT
// ==========================================

require('dotenv').config();
const express = require('express');
const cors = require('cors');
const pbxFlowroute = require('./pbx-flowroute');

const app = express();
const PORT = process.env.PORT || 3001;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Health check
app.get('/health', (req, res) => {
    res.json({ 
        status: 'healthy', 
        service: 'Horizon House PBX',
        timestamp: new Date().toISOString()
    });
});

// ==========================================
// PBX API ENDPOINTS
// ==========================================

/**
 * Make outbound call
 * POST /api/pbx/make-call
 * Body: { to: "+1234567890", from: "+1234567890", extension: "101" }
 */
app.post('/api/pbx/make-call', async (req, res) => {
    try {
        const { to, from, extension, staffPhone } = req.body;
        
        if (!to || !from) {
            return res.status(400).json({ 
                success: false, 
                error: 'Missing required parameters: to, from' 
            });
        }

        const result = await pbxFlowroute.makeOutboundCall(to, from, extension, staffPhone);
        res.json(result);
    } catch (error) {
        console.error('Error making call:', error);
        res.status(500).json({ 
            success: false, 
            error: error.message 
        });
    }
});

/**
 * Send SMS
 * POST /api/pbx/send-sms
 * Body: { to: "+1234567890", from: "+1234567890", message: "Hello" }
 */
app.post('/api/pbx/send-sms', async (req, res) => {
    try {
        const { to, from, message } = req.body;
        
        if (!to || !from || !message) {
            return res.status(400).json({ 
                success: false, 
                error: 'Missing required parameters: to, from, message' 
            });
        }

        const result = await pbxFlowroute.sendSMS(to, from, message);
        res.json(result);
    } catch (error) {
        console.error('Error sending SMS:', error);
        res.status(500).json({ 
            success: false, 
            error: error.message 
        });
    }
});

/**
 * Get call log
 * GET /api/pbx/call-log
 */
app.get('/api/pbx/call-log', (req, res) => {
    try {
        const callLog = pbxFlowroute.getCallLog();
        res.json({ success: true, calls: callLog });
    } catch (error) {
        console.error('Error fetching call log:', error);
        res.status(500).json({ 
            success: false, 
            error: error.message 
        });
    }
});

/**
 * Get voicemails
 * GET /api/pbx/voicemails
 */
app.get('/api/pbx/voicemails', (req, res) => {
    try {
        const voicemails = pbxFlowroute.getVoicemails();
        res.json({ success: true, voicemails });
    } catch (error) {
        console.error('Error fetching voicemails:', error);
        res.status(500).json({ 
            success: false, 
            error: error.message 
        });
    }
});

/**
 * Get call statistics
 * GET /api/pbx/stats
 */
app.get('/api/pbx/stats', (req, res) => {
    try {
        const stats = pbxFlowroute.getCallStats();
        res.json({ success: true, stats });
    } catch (error) {
        console.error('Error fetching stats:', error);
        res.status(500).json({ 
            success: false, 
            error: error.message 
        });
    }
});

/**
 * Handle incoming SMS webhook
 * POST /api/pbx/incoming-sms
 */
app.post('/api/pbx/incoming-sms', async (req, res) => {
    try {
        console.log('Incoming SMS:', req.body);
        const result = await pbxFlowroute.handleIncomingSMS(req.body);
        res.json(result);
    } catch (error) {
        console.error('Error handling incoming SMS:', error);
        res.status(500).json({ 
            success: false, 
            error: error.message 
        });
    }
});

/**
 * Handle incoming call webhook
 * POST /api/pbx/incoming-call
 */
app.post('/api/pbx/incoming-call', async (req, res) => {
    try {
        console.log('Incoming call:', req.body);
        const result = await pbxFlowroute.handleIncomingCall(req.body);
        res.json(result);
    } catch (error) {
        console.error('Error handling incoming call:', error);
        res.status(500).json({ 
            success: false, 
            error: error.message 
        });
    }
});

// ==========================================
// START SERVER
// ==========================================

app.listen(PORT, '0.0.0.0', () => {
    console.log('==========================================');
    console.log('🎉 HORIZON HOUSE PBX SERVER');
    console.log('==========================================');
    console.log(`✅ Server running on port ${PORT}`);
    console.log(`🌐 API accessible at http://YOUR_VM_IP:${PORT}`);
    console.log('📞 PBX Endpoints:');
    console.log(`   POST /api/pbx/make-call`);
    console.log(`   POST /api/pbx/send-sms`);
    console.log(`   GET  /api/pbx/call-log`);
    console.log(`   GET  /api/pbx/voicemails`);
    console.log(`   GET  /api/pbx/stats`);
    console.log('==========================================');
    console.log(`📱 Flowroute DID: ${process.env.FLOWROUTE_DID}`);
    console.log('==========================================');
});

// Handle graceful shutdown
process.on('SIGTERM', () => {
    console.log('SIGTERM received, shutting down gracefully');
    process.exit(0);
});

process.on('SIGINT', () => {
    console.log('SIGINT received, shutting down gracefully');
    process.exit(0);
});
