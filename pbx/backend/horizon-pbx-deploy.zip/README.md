# 🚀 HORIZON HOUSE PBX - DEPLOYMENT PACKAGE

This package contains everything needed to deploy the PBX system to your Google Cloud VM.

**VM IP: 34.45.117.126**

## 📦 Package Contents

- `server.js` - PBX API server
- `pbx-flowroute.js` - Flowroute integration
- `pbx-storage.js` - Data persistence
- `package.json` - Dependencies
- `.env` - Configuration (with your Flowroute credentials)
- `setup.sh` - Automated setup script

## 🎯 Quick Deploy (2 commands)

### In Google Cloud Shell:

```bash
# 1. Upload this folder to Cloud Shell
# (Use Upload Files button or drag-and-drop)

# 2. Copy to VM and run setup
gcloud compute scp --recurse vm-deploy horizon-pbx-server:/opt/horizon-pbx/ --zone=us-central1-a
gcloud compute ssh horizon-pbx-server --zone=us-central1-a --command="cd /opt/horizon-pbx/vm-deploy && chmod +x setup.sh && ./setup.sh"
```

### Or Manual Steps:

```bash
# SSH into VM
gcloud compute ssh horizon-pbx-server --zone=us-central1-a

# Navigate to app directory
cd /opt/horizon-pbx

# Install dependencies
npm install

# Start server
node server.js
```

## ✅ Verify Installation

```bash
# Check if server is running
curl http://localhost:3001/health

# Should return: {"status":"healthy","service":"Horizon House PBX"}
```

## 🌐 Access Your PBX

Once deployed, your PBX will be accessible at:

- **API**: http://34.45.117.126:3001
- **Health Check**: http://34.45.117.126:3001/health

## 📞 Configure Flowroute

Set your Flowroute number to route calls to:
- **Voice**: `sip:34.45.117.126:5060`
- **SMS Webhook**: `http://34.45.117.126:3001/api/pbx/incoming-sms`

## 🔧 Manage Server

```bash
# View logs
journalctl -u horizon-pbx -f

# Restart server
systemctl restart horizon-pbx

# Stop server
systemctl stop horizon-pbx
```

## 📱 API Endpoints

- `POST /api/pbx/make-call` - Make outbound call
- `POST /api/pbx/send-sms` - Send SMS
- `GET /api/pbx/call-log` - View call history
- `GET /api/pbx/voicemails` - List voicemails
- `GET /api/pbx/stats` - Call statistics

## 🆘 Troubleshooting

If server doesn't start:
```bash
# Check Node.js version
node --version  # Should be v18+

# Check dependencies
npm install

# Check .env file
cat .env  # Should have your Flowroute credentials

# Manual start (for debugging)
node server.js
```

## 💰 Cost

- VM (e2-medium): ~$25/month
- Disk (20GB): ~$2/month
- Bandwidth: ~$5-10/month
- **Total**: ~$32-37/month

---

**Support**: Your PBX system replaces 3CX and provides web-based calling, SMS, and call logging!
