#!/bin/bash
# ==========================================
# HORIZON HOUSE PBX - AUTOMATED SETUP
# ==========================================

set -e

echo "=========================================="
echo "🚀 Setting up Horizon House PBX"
echo "=========================================="

# Navigate to script directory
cd "$(dirname "$0")"

# Install Node.js dependencies
echo "📦 Installing dependencies..."
npm install

# Create systemd service
echo "🔧 Creating systemd service..."
sudo tee /etc/systemd/system/horizon-pbx.service > /dev/null << 'EOF'
[Unit]
Description=Horizon House PBX Server
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/opt/horizon-pbx/vm-deploy
ExecStart=/usr/bin/node server.js
Restart=always
RestartSec=10
Environment=NODE_ENV=production

[Install]
WantedBy=multi-user.target
EOF

# Reload systemd and enable service
echo "⚙️  Configuring service..."
sudo systemctl daemon-reload
sudo systemctl enable horizon-pbx
sudo systemctl start horizon-pbx

# Wait for server to start
echo "⏳ Waiting for server to start..."
sleep 3

# Check status
echo ""
echo "=========================================="
echo "✅ INSTALLATION COMPLETE!"
echo "=========================================="

sudo systemctl status horizon-pbx --no-pager

echo ""
echo "🌐 PBX Server Info:"
echo "   Internal: http://localhost:3001"
echo "   External: http://34.45.117.126:3001"
echo ""
echo "📝 Useful Commands:"
echo "   View logs:    sudo journalctl -u horizon-pbx -f"
echo "   Restart:      sudo systemctl restart horizon-pbx"
echo "   Stop:         sudo systemctl stop horizon-pbx"
echo "   Status:       sudo systemctl status horizon-pbx"
echo ""
echo "✅ Test: curl http://localhost:3001/health"
echo "=========================================="
